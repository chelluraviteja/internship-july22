import numpy
a, b = map(int, input().split())
A = numpy.array([input().split() for _ in range(a)], int)
print(numpy.prod(numpy.sum(A, axis=0), axis=0))