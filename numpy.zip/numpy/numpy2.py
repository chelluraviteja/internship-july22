import numpy
# Shape and Reshape in Python - Hacker Rank Solution START
print(numpy.array(input().split(), int).reshape(3, 3))
