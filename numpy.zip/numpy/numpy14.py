import numpy as np
a = int(input())
b = np.array([input().split() for _ in range(a)], float)
print(round(np.linalg.det(b),2))
