import numpy

a = tuple(map(int, input().split()))
print(numpy.zeros(a, int))
print(numpy.ones(a, int))
