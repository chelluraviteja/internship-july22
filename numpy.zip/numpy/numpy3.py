import numpy
a, b = map(int, input().split())

storage = numpy.array([input().strip().split() for _ in range(a)], int)
print (storage.transpose())
print (storage.flatten())
