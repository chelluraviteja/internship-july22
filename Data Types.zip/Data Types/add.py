a = int(input())
names = set([])
for i in range(a):
    names.add(input())
print(len(names))