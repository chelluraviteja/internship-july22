a = int(input())
b = int(input())
m = int(input())

print(pow(a,b))
print(pow(a,b,m))