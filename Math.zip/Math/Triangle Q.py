for i in range(1, int(input())):
    print((10**(i)//9)*i)