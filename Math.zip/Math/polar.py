import cmath
a= complex(input())
z = complex(a)

print(cmath.polar(z)[0])
print(cmath.polar(z)[1])